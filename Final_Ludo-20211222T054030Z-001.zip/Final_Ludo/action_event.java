public void actionPerformed(ActionEvent e)
{
	if(e.getSource()==d.dice)
	{
		randomNumber();
		flag0=true;
	}
	else if(e.getSource()==d.reset)
	{
		resetfunction();
	}	
	else if(e.getSource()==d.play)
	{
		d.f2.setVisible(true);
		d.f1.setVisible(false);
		
	}
	else if(e.getSource()==d.mmenu)
	{
		d.f2.setVisible(false);
		d.f1.setVisible(true);
		d.f.setVisible(false);
		resetFunction();
		d.screen.setText("Blue Team Chance");
	}
	else if(e.getSource()==d.exit)
	{
		System.exit(0);
	}
	else if(e.getSource()==d.option)
	{
		d.f2.setVisible(true);

	}
	else if(e.getSource()==d.okay)
	{
		d.f.setVisible(true);
		d.f1.setVisible(false);
		d.f2.dispose();
		if(d.player2.isSelected())
		{		
			nplayers=2;
			for(int q=0;q<4;q++)
			{
				d.green[q].setVisible(false);	
				d.yellow[q].setVisible(false);
								
			}
		}
		else if(d.player3.isSelected())
		{
			nplayers=3;
			for(int q=0;q<4;q++)
			{
					
				d.yellow[q].setVisible(false);
								
			}
		}
		else if(d.player3.isSelected())
		{
			nplayers=4;	
		}
	}
	else if(e.getSource()==d.help)
	{
		d.hell.setVisible(true);
	}

	for(int i=0;i<4;i++)
	{
		if(e.getSource()==d.choice[i] && flag0 == true)
		{
			if(w%nplyers==0)
			{
				d.screen.setText("Red Team chance");
				w++;
				if(((pc1[i]+rno==0)||flag1[i]==1)&&pc1[i]!=111)
				{	
					if((pc1[i]+rno)<=50)
					{
						pc1[i]=pc1[i]+rno;
						newPosition(pc1[i],i);
						for(int k=0;k<8;k++)
						{
							if(pc1[i]==safe[k])
							{
								block4=true;
								break;
							}
							else
							block4=false;
		
						}
						if(block4==false)
						cut(i);
					}
					else if(pc1[i]+rno)>50)
					{
						if((pc1[i]+rno)==51)
						pc1[i]++;
					
						pc1[i]=pc1[i]+rno;	
						System.out.println(pc1[i]);
						if(pc1[i]==57)
						newPosition(88,i);
						else if(pc1[i]<57)
						newPosition(pc1[i],i);
						
					}
					flag1[i]=1;
				}
			}
				else if(w%nplayers==1)
				{
					if(nplayers==2)
					d.screen.setText("Blue Team chance");
					else
					d.screen.setText("Green Team chance");
					w++;
	
					if(((pc2[i]+rno==13)||flag2[i]==1)&& pc2[i]!=111)
					{
						
						if((pc2[i]+rno)<=51 && block==false)
						{
							pc2[i]=pc2[i]+rno;
							newPosition(pc2[i],i);
							for(int k=0;k<8;k++)
							{
								if(pc2[i]==safe[k])
								{
									block4=true;
									break;
								}
								else
								block4=false;
			
							}
							if(block4==false)
							cut(i);
						}
						else if((pc2[i]+rno)>=51 && block==false)
						{	
							temp=pc2[i]+rno;
							pc2[i]=temp-51;
							pc2[i]--;
							newPosition(pc2[i],i);
							for(int k=0;k<8;k++)
							{
								if(pc2[i]==safe[k])
								{
									block4=true;
									break;
								}
								else
								block4=false;
			
							}
							if(block4==false)
							cut(i);
			
							block=true;
						
						}
						else if((pc2[i]+rno)>=0 && (pc2[i]+rno)<=11)
						{
							pc2[i]=pc[i]+rno;
							newPosition(pc2[i],i);
							for(int k=0;k<8;k++)
							{
								if(pc2[i]==safe[k])
								{
									block4=true;
									break;
								}
								else
								block4=false;
							}	
								if(block4==false)
								cut(i);
			
			
						}
						else if((pc2[i]+rno)>11)
							{
								temp=pc2[i]+rno;
								temp=temp-11;
								pc2[i]=56;
								pc2[i]=pc2[i]+temp;
				
								if(pc2[i]==62)
								newPosition(88,i);
								else if(pc2[i]<62)	
								newPosition(pc2[i],i);
							}				
							flag2[i]=1;		
						} 
						
					}
					else if(w%nplayers==2)
					{
						if(nplayers==3)
						d.screen.setText("Blue Team chance");
						else
						d.screen.setText("Yellow Team chance");
						w++;
						if(((pc3[i]+rno==26)||flag3[i]==1) && pc3[i]!=111)
						{
							if((pc3[i]+rno)<51 && block2==false)
							{
								pc3[i]=pc3[i]+rno;
								newPosition(pc3[i],i);
								for(int k=0;k<8;k++)
								{
									if(pc3[i]==safe[k])
									{
										block4=true;
										break;
									}
									else
									block4=false;
												
								}
								if(block4==false)
								cut(i);
							
							}
							else if((pc3[i]+rno)>=51 && block2==false)
							{
								temp=pc3[i]+rno;
								pc3[i]=temp-51;
								pc3[i]--;
								newPosition(pc3[i],i);
								for(int k=0;k<8;k++)
								{
									if(pc3[i]==safe[k])
									{
										block4=true;
										break;
									}
									else
									block4=false;
								}
									if(block4==false)
									cut(i);	
								block2=true;		
							}
							else if((pc3[i]+rno)>= 0 && (pc3[i]+rno)<=24)
							{
								pc3[i]=pc3[i]+rno;
								newPosition(pc3[i],i);
								for(int k=0;k<8;k++)
								{
									if(pc3[i]==safe[k])
									{
										block4=true;
										break;
									}
									else
									block4=false;
								}
									if(block4==false)
									cut(i);	
								
							}
							else if((pc3[i]+rno)>24)
							{
								temp=pc3[i]+rno;
								temp=temp-24;
								pc3[i]=61;
								pc3[i]=pc3[i]+temp;
								
								if(pc3[i]==67)
								newPosition(88,i);
								else if(pc3[i]<67)
								newPosition(pc3[i],i);
							
							}
							flag3[i]=1;
						}
					}
					else if(w%nplayers==3)
					{
						d.screen.setText("Blue Team Chance");	
						w++;
						if(((pc4[i]+rno==39)||flag4[i]==1) && pc4[i]!=111)
						{
								if((pc4[i]+rno)<=51 && block3==false)
								{	
									pc4[i]=pc4[i]+rno;
									newPosition(pc4[i],i);
									for(int k=0;k<8;k++)
									{
										if(pc4[i]==safe[k])
										{
											block4=true;
											break;
										}
										else
										block4=false;
									}
										if(block4==false)
										cut(i);	
								
								}
								else if((pc4[i]+rno)>=51) && block3==false)
								{
										temp=pc4[i]+rno;
										pc4[i]=temp-51;			
										pc4[i]--;
										newPosition(pc4[i],i);
									for(int k=0;k<8;k++)
									{
										if(pc4[i]==safe[k])
										{
											block4=true;
											break;
										}
										else
										block4=false;
									}
										if(block4==false)
										cut(i);	
										
									block3=true;					
										
								}
								else if((pc4[i]+rno)>=0 &&(pc4[i]+rno)<=37)
								{
									pc4[i]=pc4[i]+rno;
									newPostion(pc4[i],i);
									for(int k=0;k<8;k++)
									{
										if(pc4[i]==safe[k])
										{
											block4=true;
											break;
										}
										else
										block4=false;
									}
										if(block4==false)
										cut(i);
								}
								else if((pc4[i]+rno)>37)
								{	
									temp=pc4[i]+rno;
									temp=temp-37;
									pc4[i]=66;
									pc4[i]=pc4[i]+temp;
									if(pc4[i]==72)
									newPosition(88,i);
									else if(pc4[i]<72)
									newPosition(pc4[i],i);
								}
								flag4[i]=1;
						}
						
					}
					flag0=false;
			}
		}
	}

}
